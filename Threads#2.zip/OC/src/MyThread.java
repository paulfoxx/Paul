import javafx.scene.input.InputEvent;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyThread implements Runnable{
    boolean isInterrupt = false;
    Scanner scanner = new Scanner(System.in);
    @Override
    public void run()
    {
        while(true) {
            if(scanner.nextLine().equals("q")) {
                isInterrupt = true;
            }
        }
    }
    Queue<Integer> queue = new LinkedList();
    MyThread() throws IOException, InterruptedException {
        for (int i = 0; i < 200; i++)
        {
            queue.add((int) (Math.random() * ((100 - 1) + 1) + 1));
        }
        ExecutorService executor = Executors.newFixedThreadPool(5);
        System.out.println("---------------------Запуск----------------------------");
        while (true) {
            if (isInterrupt == false)
            {
                executor.execute(new Man1());
                executor.execute(new Man1());
                executor.execute(new Man1());
                executor.execute(new Man2());
                executor.execute(new Man2());
            }
            else
                executor.shutdown();
        }
    }


    final class Man1 implements Runnable{
        @Override
        public void run() {
            if (queue.size() <= 80) {
                int a = (int) (Math.random() * ((100 - 1) + 1) + 1);
                queue.add(a);
                System.out.println("Добавил " + a);
               /* try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }
        }
    }

    class Man2 implements Runnable{

        @Override
        public void run() {
            if (queue.size() > 0)
            {
              queue.poll();
              System.out.println("Отнял ");
            }
            else
            {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

class Main
{
    public static void main(String[] args) throws IOException, InterruptedException {
        MyThread work = new MyThread();
    }
}
