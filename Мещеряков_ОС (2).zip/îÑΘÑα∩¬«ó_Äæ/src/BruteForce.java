import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class SideThread extends Thread
{
    protected String hashfunc;
    protected int num;
    String[] word = {" " , " " ," " , " " , " "};
    String[] alphabet = {"a" , "b" , "c" , "d" , "e" , "f" , "g" , "h" , "i" , "j" , "k" , "l" , "m" , "n" , "o" , "p" , "q", "r" , "s" , "t", "u" , "v" , "w" , "x","y","z"};
    String output;
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        MessageDigest smth = MessageDigest.getInstance("SHA-256");
        return smth.digest(input.getBytes(StandardCharsets.UTF_8));
    }
    public static String toHexString(byte[] hashfunc)
    {
        BigInteger numb = new BigInteger(1, hashfunc);
        StringBuilder HexString = new StringBuilder(numb.toString(16));
        while (HexString.length() < 32)
        {
            HexString.insert(0, '0');
        }
        return HexString.toString();
    }
    public SideThread(String hashfunc , int num)
    {
        this.hashfunc = hashfunc;
        this.num = num;
    }
    public void run() {
        for(int i = 0 ; i < alphabet.length ; i++)
        {
            word[0] = alphabet[i];
            for(int k = 0 ; k < alphabet.length ; k++) {
                word[1] = alphabet[k];
                for (int l = 0; l < alphabet.length; l++) {
                    word[2] = alphabet[l];
                    for (int m = 0; m < alphabet.length; m++) {
                        word[3] = alphabet[m];
                        for (int n = 0; n < alphabet.length; n++) {
                            word[4] = alphabet[n];
                            output = word[0] + word[1] + word[2] + word[3] + word[4];
                            String CopyOutput = output;
                            try {
                                output = toHexString(getSHA(output));
                            } catch (NoSuchAlgorithmException e) {
                                e.printStackTrace();
                            }
                            if (output.equals(hashfunc)) {
                                System.out.println(CopyOutput + " | " + hashfunc + " | " +"Stream " + num + " Completed");
                                Thread.interrupted();
                            }
                        }
                    }
                }
            }
        }
    }
}

public class BruteForce {
    static SideThread FirstThread , SecondThread , ThirdThread;

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String hashfunc1 = "1115dd800feaacefdf481f1f9070374a2a81e27880f187396db67958b207cbad";
        String hashfunc2 = "3a7bd3e2360a3d29eea436fcfb7e44c735d117c42d1c1835420b6b9942dd4f1b";
        String hashfunc3 = "74e1bb62f8dabb8125a58852b63bdf6eaef667cb56ac7f7cdba6d7305c50a22f";
        FirstThread = new SideThread(hashfunc1 , 1);
        SecondThread = new SideThread(hashfunc2 , 2);
        ThirdThread = new SideThread(hashfunc3 , 3);
        FirstThread.start();
        SecondThread.start();
        ThirdThread.start();
    }
}
